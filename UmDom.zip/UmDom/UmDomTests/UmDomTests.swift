//
//  UmDomTests.swift
//  UmDomTests
//
//  Created by Даниил Кузнецов on 17.12.2024.
//

import Testing
@testable import UmDom

struct UmDomTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
