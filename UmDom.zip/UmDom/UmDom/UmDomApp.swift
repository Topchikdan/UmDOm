//
//  UmDomApp.swift
//  UmDom
//
//  Created by Даниил Кузнецов on 17.12.2024.
//

import SwiftUI

@main
struct UmDom: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
