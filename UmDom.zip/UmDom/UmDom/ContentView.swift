import SwiftUI
import SQLite3
import Combine

// MARK: - Keyboard Manager

class KeyboardManager: ObservableObject {
    @Published var keyboardHeight: CGFloat = 0
    @Published var isKeyboardVisible: Bool = false
    
    private var cancellables: Set<AnyCancellable> = []
    
    init() {
        let keyboardWillShow = NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)
            .map { notification -> CGFloat in
                if let frame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                    return frame.height.isFinite ? frame.height : 0
                }
                return 0
            }
        
        let keyboardWillHide = NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)
            .map { _ -> CGFloat in
                return 0
            }
        
        keyboardWillShow
            .merge(with: keyboardWillHide)
            .receive(on: RunLoop.main)
            .sink { [weak self] height in
                let safeHeight = height.isFinite ? height : 0
                self?.keyboardHeight = safeHeight
                self?.isKeyboardVisible = safeHeight > 0
            }
            .store(in: &cancellables)
    }
}

// MARK: - Models

/// Модель сообщения (чат). Если `imageData != nil`, значит сообщение содержит картинку.
struct Message: Identifiable {
    let id = UUID()
    let role: String  // "user" или "assistant"
    let text: String?
    let imageData: Data?
}

/// FAQ (пример — неизменённый)
struct FAQQuestion {
    let question: String
    let answer: String
}

struct FAQTopic {
    let title: String
    let questions: [FAQQuestion]
}

// MARK: - Database Manager

class DatabaseManager {
    static let shared = DatabaseManager()
    private var db: OpaquePointer?
    
    private init() {
        copyDatabaseIfNeeded()   // Копируем из бандла (если нужно)
        openDatabase()           // Открываем соединение
    }
    
    /// Копируем `UmDom.db` из бандла в Documents, если там ещё нет.
    private func copyDatabaseIfNeeded() {
        let fileManager = FileManager.default
        let documentsURL = try! fileManager.url(for: .documentDirectory,
                                                in: .userDomainMask,
                                                appropriateFor: nil,
                                                create: true)
        let dbURL = documentsURL.appendingPathComponent("UmDom.db")
        
        // --- Для теста/отладки можно удалять старую БД
        /*
        if fileManager.fileExists(atPath: dbURL.path) {
            do {
                try fileManager.removeItem(at: dbURL)
                print("Старая база удалена из Documents")
            } catch {
                print("Не удалось удалить старую базу: \(error.localizedDescription)")
            }
        }
        */
        
        // Если в Documents базы нет, копируем из бандла
        if !fileManager.fileExists(atPath: dbURL.path) {
            if let bundleURL = Bundle.main.url(forResource: "UmDom", withExtension: "db") {
                do {
                    try fileManager.copyItem(at: bundleURL, to: dbURL)
                    print("База данных скопирована в Documents: \(dbURL.path)")
                } catch {
                    print("Не удалось скопировать базу данных: \(error.localizedDescription)")
                }
            } else {
                print("Файл UmDom.db не найден в бандле.")
            }
        } else {
            print("База данных уже существует в Documents: \(dbURL.path)")
        }
    }
    
    /// Открываем соединение и создаём нужные таблицы/индексы при необходимости.
    private func openDatabase() {
        let fileManager = FileManager.default
        let documentsURL = try! fileManager.url(for: .documentDirectory,
                                                in: .userDomainMask,
                                                appropriateFor: nil,
                                                create: true)
        let dbURL = documentsURL.appendingPathComponent("UmDom.db")
        
        if sqlite3_open(dbURL.path, &db) == SQLITE_OK {
            print("База данных открыта: \(dbURL.path)")
            createSuggestionsTable()
            createUmDomTable()
            populateSuggestionsIfNeeded()
        } else {
            print("Не удалось открыть базу данных.")
        }
    }
    
    private func createSuggestionsTable() {
        let createTableQuery = """
        CREATE TABLE IF NOT EXISTS Suggestions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT NOT NULL
        );
        """
        
        let createIndexQuery = """
        CREATE INDEX IF NOT EXISTS idx_question ON Suggestions(question);
        """
        
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, createTableQuery, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Таблица Suggestions создана или уже существует.")
            } else {
                print("Не удалось создать таблицу Suggestions.")
            }
        } else if let errMsg = String(validatingUTF8: sqlite3_errmsg(db)) {
            print("Ошибка при CREATE TABLE Suggestions: \(errMsg)")
        }
        sqlite3_finalize(statement)
        
        if sqlite3_prepare_v2(db, createIndexQuery, -1, &statement, nil) == SQLITE_OK {
            _ = sqlite3_step(statement)
        }
        sqlite3_finalize(statement)
    }
    
    private func createUmDomTable() {
        let createTableQuery = """
        CREATE TABLE IF NOT EXISTS UmDom (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            "Текст запроса" TEXT NOT NULL,
            "Результат" TEXT NOT NULL,
            "PhotoData" BLOB
        );
        """
        
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, createTableQuery, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_DONE {
                print("Таблица UmDom создана или уже существует.")
            }
        }
        sqlite3_finalize(statement)
        
        // Попробуем добавить столбец, если его не было
        let alterQuery = """
        ALTER TABLE UmDom ADD COLUMN "PhotoData" BLOB
        """
        if sqlite3_prepare_v2(db, alterQuery, -1, &statement, nil) == SQLITE_OK {
            _ = sqlite3_step(statement)
            // Если столбец уже есть, будет ошибка "duplicate column name"
        }
        sqlite3_finalize(statement)
    }
    
    func populateSuggestionsIfNeeded() {
        let countQuery = "SELECT COUNT(*) FROM Suggestions;"
        var statement: OpaquePointer?
        var count: Int = 0
        
        if sqlite3_prepare_v2(db, countQuery, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_ROW {
                count = Int(sqlite3_column_int(statement, 0))
            }
        }
        sqlite3_finalize(statement)
        
        if count == 0 {
            let initialSuggestions = [
                "Когда надо устанавливать умный дом?",
                "Какие устройства входят в умный дом?",
                "Сколько стоит установка умного дома?",
                "Какие преимущества умного дома?",
                "Можно ли расширить систему умного дома позже?",
                "Как выбрать подходящую систему для моего дома?",
                "Сколько времени занимает установка системы?",
                "Какая гарантия предоставляется на оборудование?",
                "Что делать, если оборудование перестало работать?",
                "В чем экономия?",
                "Можно ли использовать собственное электричество для существенной выгоды?",
                "Есть ли круглосуточная поддержка?",
                "Как вызвать мастера для диагностики?"
            ]
            
            for suggestion in initialSuggestions {
                insertSuggestion(question: suggestion)
            }
        }
    }
    
    func insertSuggestion(question: String) {
        let insertQuery = "INSERT INTO Suggestions (question) VALUES (?);"
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (question as NSString).utf8String, -1, nil)
            _ = sqlite3_step(statement)
        }
        sqlite3_finalize(statement)
    }
    
    func fetchAllSuggestions() -> [String] {
        let query = "SELECT question FROM Suggestions;"
        var statement: OpaquePointer?
        var results: [String] = []
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                if let cStr = sqlite3_column_text(statement, 0) {
                    let question = String(cString: cStr)
                    results.append(question)
                }
            }
        }
        sqlite3_finalize(statement)
        return results
    }
    
    func fetchSuggestions(for query: String) -> [String] {
        let searchQuery = "SELECT question FROM Suggestions WHERE question LIKE ? COLLATE NOCASE LIMIT 5;"
        var statement: OpaquePointer?
        var results: [String] = []
        
        if sqlite3_prepare_v2(db, searchQuery, -1, &statement, nil) == SQLITE_OK {
            let pattern = "\(query)%"
            sqlite3_bind_text(statement, 1, (pattern as NSString).utf8String, -1, nil)
            
            while sqlite3_step(statement) == SQLITE_ROW {
                if let cString = sqlite3_column_text(statement, 0) {
                    let question = String(cString: cString)
                    results.append(question)
                }
            }
        }
        sqlite3_finalize(statement)
        
        return results
    }
    
    // ---------- Работа с таблицей UmDom ----------
    
    func insertQuery(prompt: String, result: String) {
        let insertQuery = """
        INSERT INTO UmDom ("Текст запроса", "Результат")
        VALUES (?, ?);
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (prompt as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, (result as NSString).utf8String, -1, nil)
            _ = sqlite3_step(statement)
        }
        sqlite3_finalize(statement)
    }
    
    func insertQueryWithImage(prompt: String, result: String, imageData: Data) {
        let insertQuery = """
        INSERT INTO UmDom ("Текст запроса", "Результат", "PhotoData")
        VALUES (?, ?, ?);
        """
        var statement: OpaquePointer?
        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) == SQLITE_OK {
            // Текст
            sqlite3_bind_text(statement, 1, (prompt as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, (result as NSString).utf8String, -1, nil)
            
            // Картинка
            imageData.withUnsafeBytes { (bytes: UnsafeRawBufferPointer) in
                sqlite3_bind_blob(statement, 3, bytes.baseAddress, Int32(imageData.count), nil)
            }
            _ = sqlite3_step(statement)
        }
        sqlite3_finalize(statement)
    }
    
    func fetchAllQueries() -> [(String, String, Data?)] {
        let query = "SELECT \"Текст запроса\", \"Результат\", \"PhotoData\" FROM UmDom;"
        var statement: OpaquePointer?
        var results: [(String, String, Data?)] = []
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                guard
                    let promptCStr = sqlite3_column_text(statement, 0),
                    let resultCStr = sqlite3_column_text(statement, 1)
                else {
                    continue
                }
                let prompt = String(cString: promptCStr)
                let resultText = String(cString: resultCStr)
                
                // Картинка
                let photoBytes = sqlite3_column_blob(statement, 2)
                let photoSize = sqlite3_column_bytes(statement, 2)
                
                var photoData: Data? = nil
                if let bytes = photoBytes, photoSize > 0 {
                    photoData = Data(bytes: bytes, count: Int(photoSize))
                }
                
                results.append((prompt, resultText, photoData))
            }
        }
        sqlite3_finalize(statement)
        
        return results
    }
    
    func fetchAnswer(for question: String) -> String? {
        let query = "SELECT \"Результат\" FROM UmDom WHERE \"Текст запроса\" = ? LIMIT 1;"
        var statement: OpaquePointer?
        var result: String? = nil
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (question as NSString).utf8String, -1, nil)
            if sqlite3_step(statement) == SQLITE_ROW {
                if let resultCStr = sqlite3_column_text(statement, 0) {
                    result = String(cString: resultCStr)
                }
            }
        }
        sqlite3_finalize(statement)
        
        return result
    }
    
    func clearAllQueries() {
        let deleteQuery = "DELETE FROM UmDom;"
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, deleteQuery, -1, &statement, nil) == SQLITE_OK {
            _ = sqlite3_step(statement)
        }
        sqlite3_finalize(statement)
    }
}

// MARK: - OpenAI Client

class OpenAIClient {
    private let session: URLSession
    private let baseURL = "https://api.proxyapi.ru/openai/v1"
    private let apiKey = "sk-KcZMsu01RQsvJIWTSKdmrZRlCqEZafOz"
    
    init() {
        let config = URLSessionConfiguration.default
        self.session = URLSession(configuration: config)
    }
    
    func sendRequest(prompt: String, completion: @escaping (Result<String, Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/chat/completions") else {
            completion(.failure(
                NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL"])
            ))
            return
        }
        
        let body: [String: Any] = [
            "model": "gpt-4",
            "messages": [
                ["role": "system", "content": "You are a helpful assistant."],
                ["role": "user", "content": prompt]
            ],
            "max_tokens": 256,
            "temperature": 0.7
        ]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        } catch {
            completion(.failure(error))
            return
        }
        
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let data = data, let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [
                    NSLocalizedDescriptionKey: "Нет ответа или данных"
                ])))
                return
            }
            guard httpResponse.statusCode == 200 else {
                let errMsg = "Ошибка OpenAI: статус код \(httpResponse.statusCode)"
                completion(.failure(NSError(domain: "", code: httpResponse.statusCode, userInfo: [
                    NSLocalizedDescriptionKey: errMsg
                ])))
                return
            }
            
            do {
                let completionResponse = try JSONDecoder().decode(OpenAICompletionResponse.self, from: data)
                if let firstChoice = completionResponse.choices.first {
                    let responseText = firstChoice.message.content.trimmingCharacters(in: .whitespacesAndNewlines)
                    completion(.success(responseText))
                } else {
                    completion(.failure(
                        NSError(domain: "", code: -1, userInfo: [
                            NSLocalizedDescriptionKey: "Не найдено поле choices[0].message.content"
                        ])
                    ))
                }
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
    
    func generateImage(prompt: String, completion: @escaping (Result<Data, Error>) -> Void) {
        guard let url = URL(string: "\(baseURL)/images/generations") else {
            completion(.failure(
                NSError(domain: "InvalidURL", code: -1, userInfo: [NSLocalizedDescriptionKey: "Некорректный URL для генерации"])
            ))
            return
        }
        
        let body: [String: Any] = [
            "prompt": prompt,
            "n": 1,
            "size": "512x512",
            "response_format": "b64_json"
        ]
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        } catch {
            completion(.failure(error))
            return
        }
        
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            guard let data = data, let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [
                    NSLocalizedDescriptionKey: "Нет ответа/данных"
                ])))
                return
            }
            guard httpResponse.statusCode == 200 else {
                let errMsg = "Ошибка OpenAI (image): статус код \(httpResponse.statusCode)"
                completion(.failure(NSError(domain: "", code: httpResponse.statusCode, userInfo: [
                    NSLocalizedDescriptionKey: errMsg
                ])))
                return
            }
            
            do {
                let imgResponse = try JSONDecoder().decode(OpenAIImageResponse.self, from: data)
                if let firstImage = imgResponse.data.first {
                    let b64json = firstImage.b64_json
                    if let imageData = Data(base64Encoded: b64json) {
                        completion(.success(imageData))
                    } else {
                        completion(.failure(NSError(domain: "", code: -1, userInfo: [
                            NSLocalizedDescriptionKey: "Не удалось декодировать base64"
                        ])))
                    }
                } else {
                    completion(.failure(NSError(domain: "", code: -1, userInfo: [
                        NSLocalizedDescriptionKey: "Пустой массив data"
                    ])))
                }
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}

// MARK: - OpenAI Models

struct OpenAICompletionResponse: Codable {
    let choices: [OpenAIChoice]
}

struct OpenAIChoice: Codable {
    let message: OpenAIMessage
}

struct OpenAIMessage: Codable {
    let role: String
    let content: String
}

struct OpenAIImageResponse: Codable {
    let created: Int
    let data: [OpenAIImageData]
}

struct OpenAIImageData: Codable {
    let b64_json: String
}

// MARK: - Chat Controller

class ChatController: ObservableObject {
    @Published var messages: [Message] = []
    
    private let client = OpenAIClient()
    
    func loadHistory() {
        let previousRecords = DatabaseManager.shared.fetchAllQueries()
        
        var loadedMessages: [Message] = []
        // Всегда в начале — приветствие
        loadedMessages.append(
            Message(role: "assistant",
                    text: "Вас приветствует система умной поддержки. Опишите свою проблему или задайте вопрос.",
                    imageData: nil)
        )
        
        // Дальше грузим историю
        for (prompt, answer, maybeImage) in previousRecords {
            // user
            let userMsg = Message(role: "user", text: prompt, imageData: nil)
            loadedMessages.append(userMsg)
            
            // assistant
            let assistantMsg = Message(role: "assistant", text: answer, imageData: maybeImage)
            loadedMessages.append(assistantMsg)
        }
        
        self.messages = loadedMessages
    }
    
    func sendNewMessage(content: String) {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        // Добавляем user-сообщение
        let userMsg = Message(role: "user", text: trimmed, imageData: nil)
        DispatchQueue.main.async {
            self.messages.append(userMsg)
        }
        
        // Проверяем локальную БД
        DispatchQueue.global(qos: .userInitiated).async {
            if let dbAnswer = DatabaseManager.shared.fetchAnswer(for: trimmed) {
                // В БД есть ответ
                DispatchQueue.main.async {
                    let assistantMessage = Message(role: "assistant", text: dbAnswer, imageData: nil)
                    self.messages.append(assistantMessage)
                    // Дополнительно — записываем (хотя это уже может быть в БД, на ваше усмотрение)
                    DatabaseManager.shared.insertQuery(prompt: trimmed, result: dbAnswer)
                }
            } else {
                // Идём в OpenAI
                self.client.sendRequest(prompt: trimmed) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let responseText):
                            let assistantMessage = Message(role: "assistant", text: responseText, imageData: nil)
                            self.messages.append(assistantMessage)
                            DatabaseManager.shared.insertQuery(prompt: trimmed, result: responseText)
                            
                        case .failure(let error):
                            let errorMsg = "Извините, произошла ошибка: \(error.localizedDescription)"
                            let assistantMessage = Message(role: "assistant", text: errorMsg, imageData: nil)
                            self.messages.append(assistantMessage)
                            DatabaseManager.shared.insertQuery(prompt: trimmed, result: errorMsg)
                        }
                    }
                }
            }
        }
    }
    
    func generateImageFromPrompt(_ prompt: String) {
        let trimmed = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        // user-сообщение
        let userMsg = Message(role: "user", text: "[Запрос на фото]: \(trimmed)", imageData: nil)
        DispatchQueue.main.async {
            self.messages.append(userMsg)
        }
        
        // Пишем что идёт генерация
        DispatchQueue.main.async {
            let loadingMsg = Message(role: "assistant", text: "Генерация изображения, подождите...", imageData: nil)
            self.messages.append(loadingMsg)
        }
        
        // Вызываем OpenAI
        client.generateImage(prompt: trimmed) { result in
            DispatchQueue.main.async {
                // Удаляем "Генерация..."
                if let last = self.messages.last,
                   last.text?.contains("Генерация изображения") == true {
                    self.messages.removeLast()
                }
                
                switch result {
                case .success(let imageData):
                    let assistantMsg = Message(
                        role: "assistant",
                        text: "Изображение сгенерировано по запросу: \(prompt)",
                        imageData: imageData
                    )
                    self.messages.append(assistantMsg)
                    
                    // Записываем в БД
                    DatabaseManager.shared.insertQueryWithImage(
                        prompt: prompt,
                        result: "Изображение сгенерировано по запросу: \(prompt)",
                        imageData: imageData
                    )
                    
                case .failure(let error):
                    let errorMsg = "Ошибка при генерации изображения: \(error.localizedDescription)"
                    let assistantMsg = Message(role: "assistant", text: errorMsg, imageData: nil)
                    self.messages.append(assistantMsg)
                    
                    DatabaseManager.shared.insertQuery(prompt: prompt, result: errorMsg)
                }
            }
        }
    }
}

// MARK: - Tab Manager

class TabManager: ObservableObject {
    @Published var selectedTab: Tab = .main
}

// MARK: - FAQ Topics

let faqTopics: [FAQTopic] = [
    FAQTopic(
        title: "Выбор и установка оборудования",
        questions: [
            FAQQuestion(
                question: "Как выбрать подходящую систему для моего дома?",
                answer: """
        Для правильного выбора системы нужно учитывать площадь вашего дома, текущее энергопотребление, климатические условия и ваши цели.
        Мы предоставляем бесплатную консультацию: специалист приедет на замеры, оценит все параметры и предложит оптимальное решение.
        """
            ),
            FAQQuestion(
                question: "Сколько времени занимает установка системы?",
                answer: """
        Сроки зависят от типа оборудования и сложности проекта.
        Например, установка солнечных панелей обычно занимает 2–3 дня, а полноценная система умного дома может потребовать до 5 дней.
        """
            )
        ]
    ),
    FAQTopic(
        title: "Гарантии и обслуживание",
        questions: [
            FAQQuestion(
                question: "Какая гарантия предоставляется на оборудование?",
                answer: """
        На солнечные панели предоставляется гарантия 10 лет, на устройства умного дома — 2 года.
        Продлить гарантию можно за дополнительную плату.
        """
            ),
            FAQQuestion(
                question: "Что делать, если оборудование перестало работать?",
                answer: """
        Свяжитесь с технической поддержкой (24/7).
        Мы предложим удаленную диагностику или отправим специалиста для осмотра и ремонта.
        """
            )
        ]
    ),
    FAQTopic(
        title: "Экономия и выгода",
        questions: [
            FAQQuestion(
                question: "В чем экономия?",
                answer: """
        Использование солнечных панелей и умных приборов помогает сократить потребление энергии.
        В долгосрочной перспективе это может существенно снизить ваши счета за электроэнергию.
        """
            ),
            FAQQuestion(
                question: "Можно ли использовать собственное электричество для выгоды?",
                answer: """
        Да, установив солнечные панели и системы накопления энергии, вы можете значительно снизить зависимость от сетей.
        Излишки генерации могут быть проданы обратно в сеть.
        """
            )
        ]
    ),
    FAQTopic(
        title: "Техническая поддержка и ремонт",
        questions: [
            FAQQuestion(
                question: "Есть ли круглосуточная поддержка?",
                answer: """
        Наша техподдержка доступна 24/7, вы можете обратиться в любое время.
        Мы стараемся реагировать максимально оперативно.
        """
            ),
            FAQQuestion(
                question: "Как вызвать мастера для диагностики?",
                answer: """
        Свяжитесь с нами по телефону или через чат поддержки.
        Специалист приедет и проведёт диагностику оборудования.
        """
            )
        ]
    )
]

// MARK: - Views

struct HeaderView: View {
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [Color.clear, Color(hex: "#7C4DFF"), Color.clear]),
                startPoint: .leading,
                endPoint: .trailing)
            .frame(height: 4)
            .offset(y: 30)
            
            VStack {
                HStack {
                    Image(systemName: "house.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                        .foregroundColor(Color(hex: "#7C4DFF"))
                    
                    Text("УмДом+")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(Color(hex: "#7C4DFF"))
                        .shadow(color: Color(hex: "#7C4DFF"), radius: 10, x: 0, y: 5)
                }
                
                Rectangle()
                    .fill(LinearGradient(
                        gradient: Gradient(colors: [Color(hex: "#7C4DFF"), Color.clear]),
                        startPoint: .top,
                        endPoint: .bottom))
                    .frame(height: 2)
                    .padding(.horizontal, 20)
            }
            .padding(.top, 10)
        }
        .background(Color.black.ignoresSafeArea(edges: .top))
    }
}

struct FirstScreen: View {
    var body: some View {
        ZStack {
            BackgroundLinesView()
            
            VStack {
                HeaderView()
                Spacer()
                
                VStack(spacing: 20) {
                    GradientText(text: "“УмДом+” — компания по продаже и установке экологичных решений для умного дома.",
                                 font: .system(size: 24, weight: .bold))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                    
                    GradientText(text: "Мы предлагаем как готовые комплекты, так и индивидуальные проекты.",
                                 font: .system(size: 24, weight: .bold))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                }
                
                Spacer()
            }
        }
        .background(Color.black.ignoresSafeArea())
    }
}

struct SecondScreen: View {
    @EnvironmentObject var tabManager: TabManager
    
    var body: some View {
        ZStack {
            BackgroundLinesView()
            VStack {
                HStack {
                    Button(action: {
                        tabManager.selectedTab = .main
                    }) {
                        Image(systemName: "arrow.backward")
                            .foregroundColor(Color(hex: "#7C4DFF"))
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }
                    Spacer()
                }
                .padding([.top, .leading], 20)
                
                HeaderView()
                Spacer()
                
                GradientText(text: "Немного о нас:", font: .system(size: 24, weight: .bold))
                
                Text("""
    Мы занимаемся установкой солнечных панелей, систем умного освещения, термостатов, \
    энергоэффективных бытовых приборов и многого другого для вашего комфорта.
    """)
                .multilineTextAlignment(.center)
                .foregroundColor(Color(hex: "#D1C4E9"))
                .font(.system(size: 20, weight: .medium))
                .padding(.horizontal, 30)
                
                Text("""
    Также у нас есть AI-ассистент, который подберет Вам решение и ответит на вопросы.
    """)
                .multilineTextAlignment(.center)
                .foregroundColor(Color(hex: "#D1C4E9"))
                .font(.system(size: 20, weight: .medium))
                .padding(.horizontal, 30)
                
                Spacer()
            }
        }
        .background(Color.black.ignoresSafeArea())
    }
}

struct ThirdScreen: View {
    @EnvironmentObject var tabManager: TabManager
    
    var body: some View {
        ZStack {
            BackgroundLinesView()
            VStack {
                HStack {
                    Button(action: {
                        tabManager.selectedTab = .main
                    }) {
                        Image(systemName: "arrow.backward")
                            .foregroundColor(Color(hex: "#7C4DFF"))
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }
                    Spacer()
                }
                .padding([.top, .leading], 20)
                
                HeaderView()
                
                GradientText(text: "Часто задаваемые вопросы:",
                             font: .system(size: 30, weight: .bold))
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                    .padding(.top, 60)
                    .padding(.bottom, 20)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 15) {
                        ForEach(0..<faqTopics.count, id: \.self) { index in
                            let topic = faqTopics[index]
                            NavigationLink(destination: TopicDetailScreen(topic: topic, topicIndex: index)) {
                                Text("> " + topic.title)
                                    .foregroundColor(Color(hex: "#D1C4E9"))
                                    .font(.system(size: 20, weight: .medium))
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                }
                
                Spacer()
            }
        }
        .background(Color.black.ignoresSafeArea())
    }
}

struct TopicDetailScreen: View {
    let topic: FAQTopic
    let topicIndex: Int
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            BackgroundLinesView()
            VStack {
                HStack {
                    Button(action: { dismiss() }) {
                        Image(systemName: "arrow.backward")
                            .foregroundColor(Color(hex: "#7C4DFF"))
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }
                    Spacer()
                }
                .padding([.top, .leading], 20)
                
                HeaderView()
                Spacer()
                
                GradientText(text: "Часто задаваемые вопросы:",
                             font: .system(size: 28, weight: .bold))
                    .padding(.bottom, 20)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 30) {
                        ForEach(0..<topic.questions.count, id: \.self) { qIndex in
                            FAQDisclosureGroup(
                                question: topic.questions[qIndex].question,
                                answer: topic.questions[qIndex].answer
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                }
                
                Spacer()
            }
        }
        .background(Color.black.ignoresSafeArea())
    }
}

struct FAQDisclosureGroup: View {
    let question: String
    let answer: String
    @State private var isExpanded: Bool = false
    
    var body: some View {
        DisclosureGroup(isExpanded: $isExpanded) {
            Text(answer)
                .font(.system(size: 18))
                .foregroundColor(Color(hex: "#D1C4E9"))
                .multilineTextAlignment(.leading)
                .padding(.top, 5)
        } label: {
            Text(question)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(Color(hex: "#B39DDB"))
        }
        .accentColor(Color(hex: "#7C4DFF"))
    }
}

// --- ВАЖНАЯ ЧАСТЬ: Экран чата с подсказками над TextField ---
struct SupportScreen: View {
    @EnvironmentObject var tabManager: TabManager
    @StateObject private var chatController = ChatController()
    @State private var userMessage: String = ""
    @FocusState private var isInputFocused: Bool
    
    @EnvironmentObject var keyboardManager: KeyboardManager

    @State private var showSuggestions: Bool = false
    @State private var filteredSuggestions: [String] = []
    @State private var isSelectingSuggestion: Bool = false
    
    var body: some View {
        ZStack {
            // Фон
            Color.black.ignoresSafeArea()
            
            // Слой основной верстки
            VStack(spacing: 0) {
                
                // Шапка
                HStack {
                    Button(action: {
                        tabManager.selectedTab = .main
                    }) {
                        Image(systemName: "arrow.backward")
                            .foregroundColor(Color(hex: "#7C4DFF"))
                            .padding()
                            .background(Color.white.opacity(0.1))
                            .clipShape(Circle())
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }

                    Spacer()

                    Text("УмДом+")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundColor(Color(hex: "#7C4DFF"))
                        .shadow(color: Color(hex: "#7C4DFF"), radius: 10, x: 0, y: 5)

                    Spacer()

                    // Кнопка очистки чата
                    Button(action: {
                        clearChat()
                    }) {
                        Image(systemName: "trash")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color(hex: "#7C4DFF"))
                            .clipShape(Circle())
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }
                }
                .padding([.horizontal, .top], 20)
                
                // Подзаголовок
                HStack {
                    Text("Поддержка 24/7:")
                        .foregroundColor(Color(hex: "#B39DDB"))
                        .font(.system(size: 22, weight: .bold))
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                
                // Список сообщений
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 20) {
                            ForEach(chatController.messages) { msg in
                                MessageView(message: msg)
                                    .padding(5)
                            }
                            Color.clear
                                .frame(height: 20)
                                .id("bottom")
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 10)
                        .onChange(of: chatController.messages.count) { _ in
                            withAnimation {
                                proxy.scrollTo("bottom", anchor: .bottom)
                            }
                        }
                    }
                    .onTapGesture {
                        isInputFocused = false
                    }
                }
                
            } // конец основного VStack
            
            // --- Блок подсказок НАД полем ввода ---
            if showSuggestions && !filteredSuggestions.isEmpty {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(filteredSuggestions, id: \.self) { suggestion in
                        Button(action: {
                            // Когда выбираем подсказку:
                            userMessage = suggestion
                            showSuggestions = false
                            isSelectingSuggestion = true
                            sendMessage()
                        }) {
                            HStack {
                                Image(systemName: "lightbulb.fill")
                                    .foregroundColor(Color(hex: "#7C4DFF"))
                                Text(suggestion)
                                    .foregroundColor(.white)
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Color(hex: "#7C4DFF").opacity(0.2))
                            .cornerRadius(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(Color(hex: "#1C1C1C").opacity(0.95))
                .cornerRadius(15)
                // фиксируем ширину и ставим отступ снизу, чтобы "нависать" над TextField
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 20)
                .padding(.bottom, 100)  // чтобы подсказки появлялись над нижними кнопками
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            
            // --- Поле ввода внизу ---
            VStack {
                Spacer()
                
                HStack(spacing: 10) {
                    ZStack(alignment: .leading) {
                        if userMessage.isEmpty {
                            Text("Опишите проблему...")
                                .foregroundColor(.white.opacity(0.7))
                                .padding(.horizontal, 20)
                        }
                        TextField("", text: $userMessage, onEditingChanged: { isEditing in
                            if !isEditing && !isSelectingSuggestion {
                                showSuggestions = false
                            }
                            isSelectingSuggestion = false
                        }, onCommit: {
                            showSuggestions = false
                            sendMessage()
                        })
                        .padding()
                        .foregroundColor(.white)
                        .focused($isInputFocused)
                        .onChange(of: userMessage) { newValue in
                            if newValue.isEmpty {
                                showSuggestions = false
                                filteredSuggestions = []
                            } else {
                                fetchFilteredSuggestions(query: newValue)
                            }
                        }
                    }
                    .frame(height: 50)
                    .background(Color(hex: "#7C4DFF"))
                    .cornerRadius(25)
                    .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    
                    // Кнопка "Отправить"
                    Button(action: {
                        sendMessage()
                    }) {
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(.white)
                            .padding(15)
                            .background(Circle().fill(Color(hex: "#7C4DFF")))
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }
                    .disabled(userMessage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    // Кнопка "Фото"
                    Button(action: {
                        generateImage()
                    }) {
                        Image(systemName: "photo.on.rectangle")
                            .foregroundColor(.white)
                            .padding(15)
                            .background(Circle().fill(Color(hex: "#7C4DFF")))
                            .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
            }
        }
        .onTapGesture {
            isInputFocused = false
        }
        .onAppear {
            chatController.loadHistory()
        }
    }
    
    private func sendMessage() {
        let trimmed = userMessage.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        chatController.sendNewMessage(content: trimmed)
        userMessage = ""
    }
    
    private func generateImage() {
        let trimmed = userMessage.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        chatController.generateImageFromPrompt(trimmed)
        userMessage = ""
    }
    
    private func fetchFilteredSuggestions(query: String) {
        let lowercasedQuery = query.lowercased()
        DispatchQueue.global(qos: .userInitiated).async {
            let suggestions = DatabaseManager.shared.fetchSuggestions(for: lowercasedQuery)
            DispatchQueue.main.async {
                self.filteredSuggestions = suggestions
                self.showSuggestions = !suggestions.isEmpty
            }
        }
    }
    
    private func clearChat() {
        DatabaseManager.shared.clearAllQueries()
        chatController.messages = [
            Message(role: "assistant",
                    text: "Вас приветствует система умной поддержки. Опишите свою проблему или задайте вопрос.",
                    imageData: nil)
        ]
    }
}

struct MessageView: View {
    let message: Message
    
    var body: some View {
        HStack {
            if message.role == "assistant" {
                // Левая колонка
                Image(systemName: "bubble.left.and.bubble.right.fill")
                    .foregroundColor(.white)
                    .background(
                        Circle()
                            .fill(Color(hex: "#7C4DFF"))
                            .frame(width: 40, height: 40)
                    )
                    .frame(width: 40, height: 40)
                
                VStack(alignment: .leading) {
                    if let text = message.text {
                        Text(text)
                            .foregroundColor(.white)
                            .font(.system(size: 18))
                    }
                    if let imageData = message.imageData,
                       let uiImage = UIImage(data: imageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 200, maxHeight: 200)
                            .cornerRadius(10)
                            .padding(.top, 5)
                    }
                }
                .padding(15)
                .background(Color(hex: "#7C4DFF").opacity(0.4))
                .cornerRadius(15)
                .shadow(color: Color(hex: "#7C4DFF").opacity(0.7), radius: 5, x: 0, y: 4)
                
                Spacer()
                
            } else {
                // Правая колонка (пользователь)
                Spacer()
                
                VStack(alignment: .trailing) {
                    if let text = message.text {
                        Text(text)
                            .foregroundColor(.white)
                            .font(.system(size: 18))
                    }
                    if let imageData = message.imageData,
                       let uiImage = UIImage(data: imageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 200, maxHeight: 200)
                            .cornerRadius(10)
                            .padding(.top, 5)
                    }
                }
                .padding(15)
                .background(Color(hex: "#8A63F5").opacity(0.4))
                .cornerRadius(15)
                .shadow(color: Color(hex: "#8A63F5").opacity(0.7), radius: 5, x: 0, y: 4)
                
                Image(systemName: "person.fill")
                    .foregroundColor(.white)
                    .background(
                        Circle()
                            .fill(Color(hex: "#8A63F5"))
                            .frame(width: 40, height: 40)
                    )
                    .frame(width: 40, height: 40)
            }
        }
    }
}

// Фоновые линии
struct BackgroundLinesView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ForEach(0..<10, id: \.self) { i in
                Rectangle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.clear, Color(hex: "#7C4DFF").opacity(0.5), Color.clear]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(height: 2)
                    .offset(y: CGFloat(i * 50 - 200))
            }
        }
    }
}

// Градиентный текст
struct GradientText: View {
    let text: String
    let font: Font
    
    var body: some View {
        Text(text)
            .font(font)
            .foregroundColor(.clear)
            .overlay(
                LinearGradient(
                    gradient: Gradient(colors: [Color(hex: "#746AFF"), Color(hex: "#9E59FF")]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
                .mask(
                    Text(text)
                        .font(font)
                )
            )
            .shadow(color: Color(hex: "#7C4DFF").opacity(0.8), radius: 3, x: 0, y: 3)
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r = (int >> 16) & 0xFF
        let g = (int >> 8) & 0xFF
        let b = int & 0xFF
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: 1
        )
    }
}

enum Tab: Int {
    case main = 0
    case about = 1
    case faq = 2
    case bot = 3
}

struct TabButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .foregroundColor(isSelected ? Color(hex: "#7C4DFF") : Color.white)
                Text(title)
                    .font(.system(size: 12))
                    .foregroundColor(isSelected ? Color(hex: "#7C4DFF") : Color.white)
            }
        }
    }
}

struct ContentView: View {
    @StateObject var tabManager = TabManager()
    @StateObject var keyboardManager = KeyboardManager()
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                
                ZStack {
                    switch tabManager.selectedTab {
                    case .main:
                        NavigationView {
                            FirstScreen()
                                .navigationBarHidden(true)
                        }
                        .navigationViewStyle(StackNavigationViewStyle())
                        
                    case .about:
                        NavigationView {
                            SecondScreen()
                                .navigationBarHidden(true)
                        }
                        .navigationViewStyle(StackNavigationViewStyle())
                        .environmentObject(tabManager)
                        
                    case .faq:
                        NavigationView {
                            ThirdScreen()
                                .navigationBarHidden(true)
                        }
                        .navigationViewStyle(StackNavigationViewStyle())
                        .environmentObject(tabManager)
                        
                    case .bot:
                        NavigationView {
                            SupportScreen()
                                .navigationBarHidden(true)
                        }
                        .navigationViewStyle(StackNavigationViewStyle())
                        .environmentObject(tabManager)
                        .environmentObject(keyboardManager)
                    }
                }
                .animation(.easeInOut(duration: 0.7), value: tabManager.selectedTab)
                
                Spacer(minLength: 0)
                
                // Панель вкладок, скрываем при клавиатуре
                if !keyboardManager.isKeyboardVisible {
                    HStack {
                        Spacer()
                        
                        TabButton(
                            title: "Главная",
                            icon: "house.fill",
                            isSelected: tabManager.selectedTab == .main
                        ) {
                            tabManager.selectedTab = .main
                        }
                        
                        Spacer()
                        
                        TabButton(
                            title: "О нас",
                            icon: "info.circle.fill",
                            isSelected: tabManager.selectedTab == .about
                        ) {
                            tabManager.selectedTab = .about
                        }
                        
                        Spacer()
                        
                        TabButton(
                            title: "FAQ",
                            icon: "questionmark.circle.fill",
                            isSelected: tabManager.selectedTab == .faq
                        ) {
                            tabManager.selectedTab = .faq
                        }
                        
                        Spacer()
                        
                        TabButton(
                            title: "Бот",
                            icon: "message.fill",
                            isSelected: tabManager.selectedTab == .bot
                        ) {
                            tabManager.selectedTab = .bot
                        }
                        
                        Spacer()
                    }
                    .frame(height: 60)
                    .background(Color(hex: "#1C1C1C"))
                    .shadow(color: Color.black.opacity(0.3), radius: 2, x: 0, y: -2)
                }
            }
        }
        .accentColor(Color(hex: "#7C4DFF"))
        .environmentObject(tabManager)
        .environmentObject(keyboardManager)
    }
}

// Превью
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(TabManager())
            .environmentObject(KeyboardManager())
    }
}
